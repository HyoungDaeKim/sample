package com.example.kafka.multi.service;

public interface KafkaProducerService {

    void send(String message);
}