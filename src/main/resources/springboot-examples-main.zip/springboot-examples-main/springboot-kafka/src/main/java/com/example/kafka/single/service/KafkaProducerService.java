package com.example.kafka.single.service;

public interface KafkaProducerService {

    void send(String message);
}