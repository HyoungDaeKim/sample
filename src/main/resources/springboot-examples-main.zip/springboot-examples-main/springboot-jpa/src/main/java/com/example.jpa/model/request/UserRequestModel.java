package com.example.jpa.model.request;

import lombok.Data;

@Data
public class UserRequestModel {

	private String name;
	private Integer age;
}
