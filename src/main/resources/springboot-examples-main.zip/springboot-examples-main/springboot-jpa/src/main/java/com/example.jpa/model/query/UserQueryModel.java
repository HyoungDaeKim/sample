package com.example.jpa.model.query;

import lombok.Data;

@Data
public class UserQueryModel {

	private String name;
}
