package com.example.openfeign.model;

import lombok.Data;

@Data
public class UserRequest {
    String name;
    String job;
}
