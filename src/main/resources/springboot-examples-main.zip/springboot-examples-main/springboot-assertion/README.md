# Spring Boot Assertion
This spring boot project is to demonstrate writing test cases with different assertion libraries:-

1. JUnit 5
2. AssertJ
3. Hamcrest

Check out the `test` package for various test case examples.