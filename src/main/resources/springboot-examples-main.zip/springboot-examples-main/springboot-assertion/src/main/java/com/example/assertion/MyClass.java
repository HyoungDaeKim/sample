package com.example.assertion;

public class MyClass {

    public static int add(int a, int b){
        return a+b;
    }
}
