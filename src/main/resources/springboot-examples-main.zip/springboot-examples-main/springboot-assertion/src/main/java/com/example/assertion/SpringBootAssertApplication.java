package com.example.assertion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAssertApplication {

  public static void main(String[] args) {
    SpringApplication.run(SpringBootAssertApplication.class, args);
  }

}
