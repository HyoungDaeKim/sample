package com.example.assertion.model;

import lombok.Data;

@Data
public class Person {
    private String fistName;
    private String lastName;
}
