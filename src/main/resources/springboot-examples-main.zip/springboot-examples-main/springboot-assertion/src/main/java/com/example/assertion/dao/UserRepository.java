package com.example.assertion.dao;

import com.example.assertion.model.User;

public class UserRepository {

  public User getUserById(Long userId){
    return null;
  }
}
