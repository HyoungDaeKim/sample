# springboot-email

## Overview
Email Service to compose emails using Thymeleaf HTML template and send them using spring framework's JavaMailSender
