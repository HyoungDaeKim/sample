package com.example.demoGradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import java.util.Map;
import java.util.HashMap;
import com.nshc.service.NFilterInitializer;

@SpringBootApplication
public class DemoGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoGradleApplication.class, args);
	}

	@Bean
	public ServletRegistrationBean getServletRegistrationBean() {
		ServletRegistrationBean registrationBean = new ServletRegistrationBean(new NFilterInitializer());
		registrationBean.addUrlMappings("/nf");
		registrationBean.setLoadOnStartup(1);
		Map<String, String> params = new HashMap<String, String>();
		// 절대경로 지정시
//		params.put("nFilterConfigPath", "/Users/ ... /demo/src/main/resources/static/nfilter/config/nfilter.properties");
		// 상대경로 지정시
		params.put("nFilterConfigPath", "/static/nfilter/config/nfilter.properties");
		registrationBean.setInitParameters(params);

		return registrationBean;
	}
}
